// SPDX-License-Identifier: MPL-2.0
// Copyright ijl (2022-2026)

mod borrowed;
#[cfg(all(CPython, not(Py_GIL_DISABLED)))]
mod buffer;
mod bytes;
pub(crate) mod compat;
mod fragment;
mod iterator;
mod numpy;
mod pyboolref;
#[cfg(all(CPython, not(Py_GIL_DISABLED)))]
mod pybytearrayref;
mod pybytesref;
mod pydateref;
mod pydatetimeref;
mod pydictref;
mod pyfloatref;
mod pyfragmentref;
mod pyintref;
mod pylistref;
#[cfg(all(CPython, not(Py_GIL_DISABLED)))]
mod pymemoryview;
mod pynoneref;
mod pystrref;
mod pytimeref;
mod pytupleref;
mod pyuuidref;
mod utf8;

pub(crate) use numpy::{
    NPY_ARRAY_C_CONTIGUOUS, NPY_ARRAY_NOTSWAPPED, NumpyBool, NumpyDateTimeError, NumpyDatetime64,
    NumpyDatetime64Repr, NumpyDatetimeUnit, NumpyFloat16, NumpyFloat32, NumpyFloat64, NumpyInt8,
    NumpyInt16, NumpyInt32, NumpyInt64, NumpyUint8, NumpyUint16, NumpyUint32, NumpyUint64,
    PyArrayInterface, PyCapsule,
};

pub(crate) use compat::*;

#[allow(unused_imports)]
pub(crate) use {
    borrowed::BorrowedPyRef,
    bytes::{PyBytes_AS_STRING, PyBytes_GET_SIZE, PyBytesObject},
    fragment::{Fragment, orjson_fragmenttype_new},
    iterator::{PyDictIterator, PyListIterator, PyTupleIterator},
    pyboolref::PyBoolRef,
    pybytesref::{PyBytesRef, PyBytesRefError},
    pydateref::PyDateRef,
    pydatetimeref::PyDateTimeRef,
    pydictref::PyDictRef,
    pyfloatref::PyFloatRef,
    pyfragmentref::{PyFragmentRef, PyFragmentRefError},
    pyintref::{PyIntError, PyIntKind, PyIntRef},
    pylistref::PyListRef,
    pynoneref::PyNoneRef,
    pystrref::{PyStrRef, PyStrSubclassRef, set_str_create_fn},
    pytimeref::PyTimeRef,
    pytupleref::PyTupleRef,
    pyuuidref::PyUuidRef,
};

#[allow(unused_imports)]
#[cfg(all(CPython, not(Py_GIL_DISABLED)))]
pub(crate) use {
    pybytearrayref::{PyByteArrayRef, PyByteArrayRefError},
    pymemoryview::{PyMemoryViewRef, PyMemoryViewRefError},
};

pub(crate) use pyo3_ffi::{
    METH_FASTCALL, METH_KEYWORDS, METH_O, Py_DECREF, Py_False, Py_INCREF, Py_None, Py_REFCNT,
    Py_TPFLAGS_DEFAULT, Py_TPFLAGS_DICT_SUBCLASS, Py_TPFLAGS_IMMUTABLETYPE,
    Py_TPFLAGS_LIST_SUBCLASS, Py_TPFLAGS_LONG_SUBCLASS, Py_TPFLAGS_TUPLE_SUBCLASS,
    Py_TPFLAGS_UNICODE_SUBCLASS, Py_True, Py_XDECREF, Py_hash_t, Py_intptr_t, Py_mod_exec,
    Py_ssize_t, Py_tp_dealloc, Py_tp_new, PyASCIIObject, PyBool_Type, PyBytes_FromStringAndSize,
    PyBytes_Type, PyCFunction_NewEx, PyCapsule_Import, PyCompactUnicodeObject, PyDateTime_CAPI,
    PyDateTime_DATE_GET_HOUR, PyDateTime_DATE_GET_MICROSECOND, PyDateTime_DATE_GET_MINUTE,
    PyDateTime_DATE_GET_SECOND, PyDateTime_DELTA_GET_DAYS, PyDateTime_DELTA_GET_SECONDS,
    PyDateTime_DateTime, PyDateTime_GET_DAY, PyDateTime_GET_MONTH, PyDateTime_GET_YEAR,
    PyDateTime_IMPORT, PyDateTime_TIME_GET_HOUR, PyDateTime_TIME_GET_MICROSECOND,
    PyDateTime_TIME_GET_MINUTE, PyDateTime_TIME_GET_SECOND, PyDateTime_Time, PyDict_Next,
    PyDict_Type, PyErr_Clear, PyErr_NewException, PyErr_Occurred, PyErr_SetObject, PyExc_TypeError,
    PyException_SetCause, PyFloat_AS_DOUBLE, PyFloat_FromDouble, PyFloat_Type,
    PyImport_ImportModule, PyList_New, PyList_Type, PyLong_AsLongLong, PyLong_AsUnsignedLongLong,
    PyLong_FromLongLong, PyLong_FromUnsignedLongLong, PyLong_Type, PyLongObject,
    PyMapping_GetItemString, PyMem_Free, PyMem_Malloc, PyMem_Realloc, PyMethodDef,
    PyMethodDefPointer, PyModule_AddIntConstant, PyModuleDef, PyModuleDef_HEAD_INIT,
    PyModuleDef_Init, PyModuleDef_Slot, PyObject, PyObject_GenericGetDict, PyObject_GetAttr,
    PyObject_GetAttrString, PyObject_HasAttr, PyObject_Vectorcall, PyTuple_New, PyTuple_Type,
    PyType_FromSpec, PyType_Slot, PyType_Spec, PyTypeObject, PyUnicode_AsUTF8AndSize,
    PyUnicode_FromStringAndSize, PyUnicode_InternFromString, PyUnicode_New, PyUnicode_Type,
    PyVarObject, PyVectorcall_NARGS,
};

#[allow(unused_imports, deprecated)]
pub(crate) use pyo3_ffi::PyErr_Restore;

#[cfg(CPython)]
pub(crate) use pyo3_ffi::{PyObject_CallMethodNoArgs, PyObject_CallMethodOneArg};

#[cfg(all(CPython, not(Py_GIL_DISABLED)))]
pub(crate) use pyo3_ffi::{
    Py_buffer, PyBuffer_IsContiguous, PyByteArray_AsString, PyByteArray_Size, PyByteArray_Type,
    PyMemoryView_Type,
};

#[cfg(not(CPython))]
pub(crate) use pyo3_ffi::{PyDateTime_DATE_GET_TZINFO, PyDict_SetItem, PyObject_Hash};

#[cfg(all(CPython, not(Py_GIL_DISABLED)))]
pub(crate) use buffer::PyMemoryView_GET_BUFFER;

#[cfg(not(feature = "inline_str"))]
pub(crate) use pyo3_ffi::{PyUnicode_DATA, PyUnicode_KIND};

#[cfg(Py_3_12)]
#[allow(unused_imports)]
pub(crate) use pyo3_ffi::{
    Py_MOD_MULTIPLE_INTERPRETERS_NOT_SUPPORTED, Py_mod_multiple_interpreters,
    PyErr_GetRaisedException, PyErr_SetRaisedException, PyType_GetDict,
};

#[cfg(not(Py_3_12))]
#[allow(unused_imports)]
pub(crate) use pyo3_ffi::{PyErr_Fetch, PyErr_NormalizeException};

#[cfg(not(Py_3_13))]
pub(crate) use pyo3_ffi::PyModule_AddObjectRef;

#[cfg(Py_3_13)]
pub(crate) use pyo3_ffi::PyModule_Add;

#[cfg(all(CPython, Py_3_13))]
pub(crate) use pyo3_ffi::{PyDict_Contains, PyDictObject};

#[cfg(Py_3_13)]
#[allow(unused_imports)]
pub(crate) use pyo3_ffi::{Py_MOD_GIL_NOT_USED, Py_MOD_GIL_USED, Py_mod_gil};

#[cfg(Py_3_15)]
#[allow(unused_imports)]
pub(crate) use pyo3_ffi::PyFrozenDict_New;
